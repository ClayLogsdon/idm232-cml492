<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
  <!-- <link rel="shortcut icon" href="assets/ico/favicon.png"> -->

  <title>Backend</title>

  <!-- Icons -->
  <link href="<?php echo DOMAIN ?>/admin/node_modules/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo DOMAIN ?>/admin/node_modules/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

  <!-- Main styles for this application -->
  <link href="<?php echo DOMAIN ?>/admin/css/style_core_ui.css?version=<?php echo VERSION ?>" rel="stylesheet">
 <link href="<?php echo DOMAIN ?>/admin/css/new-css.css?version=<?php echo VERSION ?>" rel="stylesheet">
  <!-- Styles required by this views -->

</head>
<body class="app flex-row align-items-center" id="body_part">

  <div class="col-12 head-div" >
  <div class="row">
    <a class="col-lg-1 col-6" href="#"><img src="images/image11.png" width="100"/></a>
    <a class="col-lg-9 col-6 col-offset-1 text-center" href="#"><img src="images/logo.png" width="250"/></a>
	</div>
  </div>