<?php
session_start();
require_once '../config.php';
require_once '../database.php';
require_once 'check_session.php';

require_once 'auth.php';

$auth = array('general');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    header('Location: ../index.php');
    exit;
}

class Impressum extends database{
	
  public function all($id)
  {
	  
    return $this->fetchAll("tb_session",null,'created_at','DESC');
  }
}

$obj = new Impressum();
$Posts = $obj->all($id);


include 'header.php';
?>

<!-- Main content -->
    <main class="main">

      <!-- Breadcrumb -->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">Sessions</li>
        
        <li class="breadcrumb-item active">List</li>

        <!-- Breadcrumb Menu-->
<!--        <li class="breadcrumb-menu d-md-down-none">
          <div class="btn-group" role="group" aria-label="Button group">
            <a class="btn" href="#"><i class="icon-speech"></i></a>
            <a class="btn" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
            <a class="btn" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
          </div>
        </li>-->
      </ol>

      <div class="container-fluid">
        <div class="animated fadeIn">
			
            <div class="col-sm-12">
              <div class="card">
                <div class="card-header">
                    Sessions
					
                </div>
                <div class="card-body">
                  <?php include_once "../check_errors.php";?>
                 
					     <table class="table table-responsive-sm table-bordered" id="abradant-table">
                    <thead>
                      <tr>
                        <th>Name</th>
						<th>Description</th>
						<th>Start Date</th>
						<th>End Date</th>
						<th>Time</th>
						
                        <th>

                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      if(!empty($Posts))
                      foreach($Posts AS $pos)
                      {
                        ?>
                        <tr>
                          <td>
                            <?php echo htmlspecialchars($pos[COLUMN_PREFIX . '_name']) ;?>
                          </td>
						  <td>
                            <?php echo htmlspecialchars($pos[COLUMN_PREFIX . '_description']) ;?>
                          </td>
                         <td>
                            <?php echo date('d-m-Y', strtotime($pos[COLUMN_PREFIX . '_start_date'])) ;?>
                          </td>
						   <td>
                            <?php echo date('d-m-Y', strtotime($pos[COLUMN_PREFIX . '_end_date'])) ;?>
                          </td>
						  <td>
                            <?php echo ($pos[COLUMN_PREFIX . '_time']) ;?>
                          </td>
						
                          <td class="action_container">
                           <a href="welcome.php?id=<?php echo htmlspecialchars($pos['cl_id']);?>" class="btn btn-success btn-sm"><b>Join</b>  <i class="fa fa-arrow-right"></i></a>
							 
               <div class="error-input"></div></td>
                        </tr>
                        <?php
                      }
                      ?>
                    </tbody>
                    
                  </table>
                </div>
					</div>
				</div>
				
			</div>
			
		
	</div> <!-- end #page-content -->
</main>
      
<?php
include 'right_side.php';
?>
</div>
<?php
include 'footer.php';
?>