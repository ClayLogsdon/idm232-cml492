<?php
session_start();
require_once '../../config.php';
require_once '../../database.php';
require_once '../check_session.php';
require_once '../auth.php';

$auth = array('admin');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    header('Location: ../index.php');
    exit;
}



class Categorylist extends database{
	
  public function all($search, $page)
  {
      if(trim($search) == '')
      {
	    return $this->fetchAll("tb_category", null, 'created_at', 'DESC', ($page - 1) * NO_OF_RECORDS, NO_OF_RECORDS);
      }
      else
      {
          $sql = ' SELECT * FROM  tb_category WHERE cl_name LIKE ? ORDER BY created_at DESC LIMIT ' . ($page - 1) * NO_OF_RECORDS . 
                  ',' . NO_OF_RECORDS;
          return $this->callQuery($sql, [$search . '%']);
      }
  }
 
}


$search = '';
if(isset($_GET['search']))
{
    $search = $_GET['search'];
}

$page = 1;
if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 1)
{
  $page = $_GET['page'];
}


$obj = new Categorylist();
$list = $obj->all($search, $page);


include '../header.php';
?>

<!-- Main content -->
    <main class="main pb-5 col-12">
	<div class="container text-center search-container mt-2">
			<form methos="GET" action="../recipe/list.php">
			  <input class="search px-3" name='search' type="text" placeholder="Search.." value="<?php echo htmlspecialchars($search) ?>" name="search">
			  <button type="submit" class="search-icon"><img src="../images/Search Icon.png"></button>
			</form>
		  </div>
    <div class="container">
		<center><a href="add.php" class="btn btn-secondary mb-5 btn-add">Add Category</a></center>
		<?php include_once "../check_errors.php";?>
<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        
		  <?php
                      if(!empty($list))
                      foreach($list AS $pos)
                      {
						
                        ?>
        <div class="col-md-4 cluster-container">
          <div class="card shadow-sm">
            <?php
				if($pos[COLUMN_PREFIX . '_image'] =="")
				{ ?>
					<img class="bd-placeholder-img card-img-top" src="<?php echo DOMAIN ?>/admin/uploads/no-image.jpg" width="100%" height="100"/>
				<?php }
				else
				{
			?>
			<img class="bd-placeholder-img card-img-top" src="<?php echo DOMAIN ?>/admin/uploads/<?php echo htmlspecialchars($pos[COLUMN_PREFIX . '_image']) ;?>" width="100%" />
			<?php
				}
				?>
            <div class="card-body">
              <h3 class="card-text text-center recipe-n"><?php echo htmlspecialchars($pos[COLUMN_PREFIX . '_name']); ?> </h3>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <a href="../recipe/list.php?id=<?php echo htmlspecialchars($pos['cl_id']);?>" class="btn btn-primary mr-1"><i class="fa fa-eye">Recipe</i></a> 
				   <a href="edit.php?id=<?php echo htmlspecialchars($pos['cl_id']);?>" class="btn btn-success mr-1"><i class="fa fa-edit"></i></a>
				<button type="button" class="btn btn-delete btn-danger" cluster-confirm="Are you sure you want to delete this data?" cluster-href="../ajax/recipe/delete_ajax.php?id=<?php echo htmlspecialchars($pos['cl_id']);?>"><i class="fa fa-trash"></i></button>
                <div class="error-input"></div>
				</div>
                <!--<small class="text-muted">9 mins</small>-->
              </div>
            </div>
          </div>
        </div>
          <?php
						  
                      }
                      ?>
		<center>
		<nav aria-label="Page navigation example">
					  <ul class="pagination justify-content-center">
						<?php
						if($page > 1)
						  { ?>
						<li class="page-item"><a class="page-link" href="?page=<?php echo ($page - 1) ?>">Previous</a></li>
						<?php
					  }
						if(count($list) >= NO_OF_RECORDS)
						  { ?>
						<li class="page-item"><a class="page-link" href="?page=<?php echo ($page + 1) ?>">Next</a></li>
					  <?php } ?>
					  </ul>
					</nav>
		</center>
      </div>
			
		
	</div> <!-- end #page-content -->
</main>
      
<?php
include '../right_side.php';
?>
</div>
<?php
include '../footer.php';
?>