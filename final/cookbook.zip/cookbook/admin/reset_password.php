<?php
session_start();

include_once "../config.php";
include_once "../database.php";
require_once 'check_session.php';
include_once "auth.php";
$auth = array('coach', 'admin');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    http_response_code(401);
	echo json_encode(array('error_text' => 'Authntication Error'));
	exit;
}
include 'header.php';
?>

<!-- Main content -->
    <main class="main">

      <!-- Breadcrumb -->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">Password</li>
        
        <li class="breadcrumb-item active">Reset</li>

        <!-- Breadcrumb Menu-->
<!--        <li class="breadcrumb-menu d-md-down-none">
          <div class="btn-group" role="group" aria-label="Button group">
            <a class="btn" href="#"><i class="icon-speech"></i></a>
            <a class="btn" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
            <a class="btn" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
          </div>
        </li>-->
      </ol>

      <div class="container-fluid">
        <div class="animated fadeIn">
			
            <div class="col-sm-12">
              <div class="card">
	<form method="post" id="form" cluster-url="ajax/reset_password_user.php" cluster-warning="Resetting Password......" cluster-redirect="reset_password.php">
                <div class="card-header">
                   Update Password
                </div>
                <div class="card-body">
                   <div class="error-main"></div>
                    <div class="form-group col-xs-12 input-container">
                        <label for="focusedinput" class="col-xs-12 control-label">Current Password*</label>
                        <div class="col-xs-12 contact-input">
                            <input placeholder="Password" type="password" class="form-control" name="password" id="password" />
                            <div class="error-input"></div>
                        </div>
                    </div>
                   
								
								

								<div class="form-group col-xs-12 input-container">
									<div class="col-xs-12 control-label">New Password*</div>
									<div class="col-xs-12 contact-input">
										<input type="password" class="form-control" placeholder="New Password" id="new_password" name="new_password" />
										<div class="error-input"></div>
									</div>
								</div>

								<div class="form-group col-xs-12 input-container">
									<div class="col-xs-12 control-label">Confirm Password*</div>
									<div class="col-xs-12 contact-input">
										<input type="password" class="form-control contact-us-input" placeholder="Confirm Password" id="confirm_password" name="confirm_password" />
										<div class="error-input"></div>
									</div>
								</div>

								
								
								<div class="form-group col-xs-12 input-container">
									<div class="col-xs-12 col-sm-8 col-sm-offset-4 contact-input no-padding">
										<button type="submit" class="btn btn-success menu-btn top-margin register-submit" id="btn-submit">Submit</button>
										<div class="error-input"></div>
									</div>
								</div>

							</div>
							
						</form>
					</div>
				</div>
				
			</div>
			
		
	</div> <!-- end #page-content -->
</main>
<?php
include 'right_side.php';
?>
</div>
<?php
include 'footer.php';
?>