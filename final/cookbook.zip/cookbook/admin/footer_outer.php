<footer id="footer" class="fusion-footer-copyright-area" >
		<div class="fusion-row">
			<div class="fusion-copyright-content">

				<div class="fusion-copyright-notice" style="padding-bottom: 0px;">
		<div>
		Powered by <b><a href="https://clusterinfos.com/"> Clusterinfos.com</a></b>	</div>
</div>
<div class="fusion-social-links-footer" style="display: none;">
	</div>

			</div> <!-- fusion-fusion-copyright-content -->
		</div> <!-- fusion-row -->
	</footer>

<script src="<?php echo DOMAIN ?>/admin/node_modules/jquery/dist/jquery.min.js"></script>
<!-- Scripts -->
<script src="<?php echo DOMAIN ?>/admin/js/jquery.ba-outside-events.min.js"></script>
<script src="<?php echo DOMAIN ?>/admin/js/jquery.responsive-tabs.js"></script>
<script src="<?php echo DOMAIN ?>/admin/js/jquery.flexslider-min.js"></script>
<script src="<?php echo DOMAIN ?>/admin/js/jquery.fitvids.js"></script>
<script src="<?php echo DOMAIN ?>/admin/js/jquery-ui-1.10.4.custom.min.js"></script>
<script src="<?php echo DOMAIN ?>/admin/js/jquery.inview.min.js"></script>
<script src="<?php echo DOMAIN ?>/admin/js/script.js"></script>

</body>
</html>