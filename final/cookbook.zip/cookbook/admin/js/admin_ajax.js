$(document).ready(function(){

  /* insertion */
	$('#form_admin').submit(function(e){
		e.preventDefault();
		$('#btn-submit').attr('disabled', 'disabled');
		var url = $(this).attr('cluster-url');
		var data = $('#form_admin').serializeArray();
    var redirect = $(this).attr('cluster-redirect');
		

		$('.error-main').html('<div class="alert alert-warning">Please wait while we process your input....</div>');
         
          window.location.href = '#form_admin';



          $.post('../ajax/admin/' + url, {data:data}, function(res){
          	$('#btn-submit').removeAttr('disabled');
          	console.log(res);
              $('.error-main').html('<div class="alert alert-success">' + res.message + '</div>').show();
              //$('.btn-submit').removeAttr('disabled');
              window.location.href = '#form_admin';
             if (typeof redirect !== typeof undefined && redirect !== false) {
                  window.location.href = redirect;
              }
              else
              {
                location.reload();
              }
          },'json')
        .fail(function(xhr) {

          $('#btn-submit').removeAttr('disabled');
          $('.error-main').html('<div class="alert alert-danger">Following errors are listed. Please check errors and resubmit the form.</div>').show();
          	$('.error-input').html('');
            var html = '';
            var res = xhr.responseJSON;

            if (typeof res === 'undefined') {
            	$('.error-main').html('<div class="alert alert-danger">Something went wrong</div>').show();
              return;
            }
            if (typeof res.error_description === 'undefined') {
            	if(typeof res.error_text === 'undefined')
            	{
	            	$('.error-main').html('<div class="alert alert-danger">Something went wrong</div>').show();
	            	window.location.href = '#form_admin';
	            	return;
	            }
	            else
	            {
	            	$('.error-main').html('<div class="alert alert-danger">' + res.error_text + '</div>').show();
	            	window.location.href = '#form_admin';
	            	return;
	            }
            }
          
          // var res1 = $.parseJSON('"' + res + '"');
           $.each(res.error_description, function(i, value) {
           		var parent = $('#' + i).parents('.input-container').first();
           		$(parent).find('.error-input').append('<div class="alert alert-danger alert-flat">' + value + '</div>');
                
            });
            
            
            window.location.href = '#form_admin';
        },'json');;
    });


  /* insertion */
  $('.btn-delete').click(function(e){
    var conf = confirm("Are you sure you want to delete this?");
    if(!conf)
    {
      return;
    }
    var current = $(this);
    $(current).attr('disabled', 'disabled');
    var url = $(this).attr('data-href');
    var parent = $(this).parents('.action-container').first();
    var mainParent = $(this).parents('tr').first();
    var id = $(current).attr('data-id');

    $(parent).find('.error-input').html('<div class="alert alert-warning">Please wait while we delete data....</div>');
          $.post('../ajax/admin/' + url, {id:id}, function(res){
          
              $(mainParent).remove();
          },'json')
        .fail(function(xhr) {

          $(current).removeAttr('disabled');
            
            var html = '';
            var res = xhr.responseJSON;

            if (typeof res === 'undefined') {
              $(parent).find('.error-input').html('<div class="alert alert-danger">Something went wrong</div>').show();
              return;
            }
            if (typeof res.error_description === 'undefined') {
              if(typeof res.error_text === 'undefined')
              {
                $(parent).find('.error-input').html('<div class="alert alert-danger">Something went wrong</div>').show();
               
                return;
              }
              else
              {
                $('.error-main').html('<div class="alert alert-danger">' + res.error_text + '</div>').show();
                return;
              }
            }
          
        },'json');;
    });


 
});