$(document).ready(function(){

  /* insertion */
	$('#form_admin_edit').submit(function(e){
		e.preventDefault();
    var conf = confirm("Are you sure you want to delete");
		$('#btn-submit').attr('disabled', 'disabled');
		var url = $(this).attr('data-url');
		var data = $('#form_admin_edit').serializeArray();
		

		$('.error-main').html('<div class="alert alert-warning">Please wait while we process your input....</div>');
         
          window.location.href = '#form_admin_edit';



          $.post('../ajax/admin/' + url, {data:data, id:editID}, function(res){
          	$('#btn-submit').removeAttr('disabled');
          	console.log(res);
              $('.error-main').html('<div class="alert alert-success">' + res.message + '</div>').show();
              //$('.btn-submit').removeAttr('disabled');
              window.location.href = '#form_admin_edit';
             location.reload();
          },'json')
        .fail(function(xhr) {

          $('#btn-submit').removeAttr('disabled');
          $('.error-main').html('<div class="alert alert-danger">Following errors are listed. Please check errors and resubmit the form.</div>').show();
          	$('.error-input').html('');
            var html = '';
            var res = xhr.responseJSON;

            if (typeof res === 'undefined') {
            	$('.error-main').html('<div class="alert alert-danger">Something went wrong</div>').show();
            }
            if (typeof res.error_description === 'undefined') {
            	if(typeof res.error_text === 'undefined')
            	{
	            	$('.error-main').html('<div class="alert alert-danger">Something went wrong</div>').show();
	            	window.location.href = '#form_admin_edit';
	            	return;
	            }
	            else
	            {
	            	$('.error-main').html('<div class="alert alert-danger">' + res.error_text + '</div>').show();
	            	window.location.href = '#form_admin_edit';
	            	return;
	            }
            }
          
          // var res1 = $.parseJSON('"' + res + '"');
           $.each(res.error_description, function(i, value) {
           		var parent = $('#' + i).parents('.input-container').first();
           		$(parent).find('.error-input').append('<div class="alert alert-danger alert-flat">' + value + '</div>');
                
            });
            
            
            window.location.href = '#form_admin_edit';
        },'json');;
    });


 
});