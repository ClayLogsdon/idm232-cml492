<?php
session_start();
setcookie('token1',"" ,time()-3600, '/');
setcookie('token2',"" ,time()-3600, '/');

header('Location: login.php');
exit;