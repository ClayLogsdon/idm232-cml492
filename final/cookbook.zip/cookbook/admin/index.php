<?php
require_once '../config.php';
require_once '../database.php';
require_once 'check_session.php';
if($user['cl_type'] =='admin' || $user['cl_type'] =='company')
{
	header('Location: category/list.php');
	exit;
	exit;
}

else
{
	header('Location: ' . DOMAIN . '/admin/login.php');
	exit;
}
?>