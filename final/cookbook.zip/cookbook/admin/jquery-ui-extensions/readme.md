This repository is not actively maintained. It works with whatever version of
jQuery UI is used in the demos. There are no tests and I don't use any of these
in any of my code anywhere. Individual extensions may or may not work with newer
version of jQuery UI.

At some point in 2013, I will update all of this code, add tests, support
multiple versions of jQuery UI, create several more extensions and post these
on the new plugins site.

If you're looking for the `selectFirst` extension for autocomplete, check the
[1-8 branch](https://github.com/scottgonzalez/jquery-ui-extensions/tree/1-8).
`selectFirst` has been removed from master because the option was rolled into
newer versions of jQuery UI as the
[`autoFocus`](http://api.jqueryui.com/autocomplete/#option-autoFocus) option.

Support this project by [donating on Gittip](https://www.gittip.com/scottgonzalez/).
