<?php

session_start();
require_once '../database.php';
require_once '../config.php';

class Curl
{
    /** @var resource cURL handle */
    private $ch;

    /** @var mixed The response */
    private $response = false;

    /**
     * @param string $url
     * @param array  $options
     */
    public function __construct($url, array $options = array())
    {
        $this->ch = curl_init($url);

        foreach ($options as $key => $val) {
            curl_setopt($this->ch, $key, $val);
        }

        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
    }

    /**
     * Get the response
     * @return string
     * @throws \RuntimeException On cURL error
     */
    public function getResponse()
    {
         if ($this->response) {
             return $this->response;
         }

        $response = curl_exec($this->ch);
        $error    = curl_error($this->ch);
        $errno    = curl_errno($this->ch);

        if (is_resource($this->ch)) {
            curl_close($this->ch);
        }

        if (0 !== $errno) {
            throw new \RuntimeException($error, $errno);
        }

        return $this->response = $response;
    }

    /**
     * Let echo out the response
     * @return string
     */
    public function __toString()
    {
        return $this->getResponse();
    }
}


class register extends database
{



   public function check($username)
    {
        $where['username']=$username;
         return $this->fetchRow('user', $where);
    }
    public function index($data)
    {
		$count=$this->current_count();
		$data['user_code']=$count['prefix'].'-'.$count['count'];
		$data1['count']=$count['count']+1;
		$where1['id']=$count['id'];
		$this->update('auto_incre', $data1,$where1);
        return $this->insert('user', $data);
    }
	 public function current_count()
    {
       
         return $this->fetchRow('auto_incre');
    }
}
$msg="";
if(isset($_POST['data']))
{
	if(!isset($_POST['g-recaptcha-response']) || trim($_POST['g-recaptcha-response']) == '')
	{
		$msg.= "Please check I am not a robot<br/>";
	}
	
	$data=$_POST['data'];

	if(trim($data['username']) == '')
	{
		$msg.= "Username is required<br/>";
	}
	if(trim($data['password']) == '')
	{
		$msg.= "Passowrd is required<br/>";
	}
	if(trim($data['name']) == '')
        {
            $msg.= "Name is Required<br/>";
        }
        else
{
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email format<br/>"; 
      }
}

if(trim($data['password']) == '')
{
    $msg.= "Password is Required<br/>";
}

if(trim($data['cpass']) == '')
{
    $msg.= "Confirm password is Required<br/>";
}
if(trim($data['cpass']) != trim($data['password']))
{
    $msg.= "Password Mismatch<br/>";
}
else {
    $data['password']=password_hash($data['password'], PASSWORD_DEFAULT);
     unset($data['cpass']);
    
}
$index = new register();
$res1 = $index->check($data['username']);
if($res1)
{
    $msg.= "Username already exists.<br/>";
} 

if(isset($_FILES['image']['tmp_name']) && is_uploaded_file($_FILES['image']['tmp_name']))
{
    $uploadOk = 1;
    $target_dir = "uploads/";
    $randName = date('dmYhis') . rand(10000,99999) . basename($_FILES['image']["name"]);
    $target_file = $target_dir . $randName;
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    
    // Check if file already exists
    if (file_exists($target_file)) {
        $msg.=  "Sorry, file already exists.";
        $uploadOk = 0;
    }
    // Check file size
    if ($_FILES['image']["size"] > 500000000) {
        $msg.=  "Sorry, your file is too large.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" && $imageFileType != "pdf") {
        $msg.=  "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        $msg.=  "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES['image']["tmp_name"], $target_file)) {
            $uploadOk = 1;
            $data['passport'] = $target_file;
        } else {
            $message.=  "Sorry, there was an error uploading your file.";
        }
    }
}
 else
 {
     $msg.= "Passport Copy is required<br/>";
 }

	if($msg=="")
	{
		
		$res = $index->index($data);
                if($res)
                {
                    $msg ="Your Registration is Successfull. One of our activation team member will be in contact to activate your account.";
			header('Location: login.php?message=' . $msg);
exit;
                }
            else {
                 $msg ="Something went wrong";
            }
	}
	
}

include_once "header_outer.php";
?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mx-4">
                    <div class="card-block p-4">
                        <h1>Forgot Password</h1>
                        <p class="text-muted">Enter your Email</p>
                        <form  method="post" id="form" id="form" cluster-url="ajax/forgot_password.php" cluster-warning="Sending Reset Link to Email...." cluster-redirect="forgot.php">
                            <?php include_once "../check_errors.php";?>
                          <div class="error-main"></div>
                           <div class="form-group col-xs-12 input-container">
                              <label for="focusedinput" class="col-xs-12 control-label">Email Address*</label>
                              <div class="col-xs-12 contact-input">
                                  <input placeholder="Email" type="email" class="form-control" name="email" id="email"  />
                                  <div class="error-input"></div>
                              </div>
                          </div>
                          
                          <button type="submit" class="btn btn-block btn-success">Send Reset Link to Email</button>
                      </form>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

    <?php include_once "footer_outer.php"; ?>