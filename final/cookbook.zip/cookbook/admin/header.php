<?php
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

$arr = explode(DOMAIN, $actual_link);
$link = $arr[1];

$linkArray = explode('?', $link);
$path = $linkArray[0];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
  <link rel="shortcut icon" href="/img/favicon.png">
  <title>
  <?php 
  if($user['cl_type'] == 'admin')
  {
  echo 'Admin';
  }
  else if($user['cl_type'] == 'user')
  {
	  echo 'User';
  }
   else if($user['cl_type'] == 'company')
  {
	  echo 'Company';
  }
 
  ?> Panel
  </title>

  
  <!-- Icons -->
  <link href="<?php echo DOMAIN ?>/admin/node_modules/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo DOMAIN ?>/admin/node_modules/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
<!-- <link rel="stylesheet" href="/datepicker/datepicker3.css">-->
<link rel="stylesheet" href="<?php echo DOMAIN ?>/admin/datepicker/dist/css/default/zebra_datepicker.css">

  <!-- Main styles for this application -->
  <link href="<?php echo DOMAIN ?>/admin/css/style_core_ui.css?version=<?php echo VERSION ?>" rel="stylesheet">
  <!-- Styles required by this views -->
  
  <link href="<?php echo DOMAIN ?>/admin/jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css" />

  <link href="<?php echo DOMAIN ?>/admin/dropzone/dist/dropzone.css" rel="stylesheet" />

  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Play&display=swap" rel="stylesheet">

<link href="https://cdn.datatables.net/responsive/2.2.7/css/responsive.dataTables.min.css" rel="stylesheet">
<link href="<?php echo DOMAIN ?>/admin/css/new-css.css" rel="stylesheet">

<link href="<?php echo DOMAIN ?>/css/divu-style.css?version=<?php echo VERSION ?>" rel="stylesheet" />
  
  <script src="<?php echo DOMAIN ?>/admin/node_modules/jquery/dist/jquery.min.js"></script>
  <script src="<?php echo DOMAIN ?>/admin/jquery-ui/jquery-ui.min.js"></script>

    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/responsive/2.2.7/js/dataTables.responsive.min.js"></script>
 
  <script src="<?php echo DOMAIN ?>/admin/ckeditor4/ckeditor.js"></script>
  <script src="<?php echo DOMAIN ?>/admin/js/script.js?version=<?php echo VERSION ?>"></script>

   <script src="<?php echo DOMAIN ?>/admin/jquery-ui-extensions/src/autocomplete/jquery.ui.autocomplete.html.js"></script>

  <script>
    var editID = '0';
  </script>
  
  
  <style>
        .main
        {
            margin-top: 0px;
            padding-top: 200px;
            background-color: #FFFAF4 !important
        }
        
        .head-div
        {
            position: unset;
        }
        
        .menu
        {
            position: unset;
            top: auto;
        }
        
        header
        {
            z-index: 10;
            
        }
        
        .navbar
        {
            background-color: #FFFAF4 !important;
        }
    </style>
</head>


<body class="bg-white" id="body_part">
  <input type="hidden" class="domain" value="<?php echo DOMAIN ?>" />
 
  
  <div class="container-fluid " style="display: block;">
     <div class='row'>
         <header class=" col-12" style="position: fixed">
          
		    <div class="row">
                        <div class="head-div">
                            <div class="row">
                    <div class="col-lg-1 col-4 header_logo_div" href="#"><img src="<?php echo DOMAIN ?>/assets/image11.png" width="100"/></div>
                    <div class="col-lg-9 col-8 header_logo_div header_logo_text col-lg-offset-1 text-center" href="#">
                        The Lebanese Cookbook
                    </div>
                            </div>
                        </div>
	</div>
            
             <nav class="navbar navbar-expand-lg navbar-dark" >
            <div class="col-12">
                <div class="row">
			<div class="col-12 menu ">
				<div class="row">
				 <div class="col  text-center">
					<a class="text-decoration-none
                                           " href="<?php echo DOMAIN ?>">Home</a>
				 </div>
				 <div class="col   text-center">
					 <a class="text-decoration-none
                                            <?php
                                           if($path == '/admin/category/list.php')
                                           {
                                               echo 'active';
                                           }
                                           
                                           ?>" href="<?php echo DOMAIN ?>/admin/category/list.php">Categories</a>
				 </div>
				 <div class="col   text-center">
					 <a class="text-decoration-none
                                             <?php
                                           if($path == '/admin/recipe/list.php')
                                           {
                                               echo 'active';
                                           }
                                           
                                           ?>" href="<?php echo DOMAIN ?>/admin/recipe/list.php">All Recipes</a>
				 </div>
                                    
                                    <?php
                                    if(isset($user))
                                    {
                                        ?>
                                    
                                    <div class="col  text-center">
					 <a class="text-decoration-none" href="<?php echo DOMAIN ?>/admin/logout_user.php">Logout</a>
				 </div>
                                    <?php
                                    }
                                    ?>
				</div>
			
			 </div>
                </div>
            </div>
        </nav>
		
	  </header>
      
      
     
      
      
	 