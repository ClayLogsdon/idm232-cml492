<?php
if(!isset($_GET['a']) || !isset($_GET['b']) || !isset($_GET['c']) || !is_numeric($_GET['c']) || trim($_GET['a']) == '' || trim($_GET['b']) == '' || trim($_GET['c']) == '' || trim($_GET['a']) == null || trim($_GET['b']) == null || trim($_GET['a']) == 'null' || trim($_GET['b']) == 'null')
{
	header('Location: index.php');
	exit;
}
session_start();
include_once "../config.php";
include_once "../database.php";

class ResetPasswordLink extends database
{
	public function checkUser($where)
	{
		return $this->fetchRow(TABLE_PREFIX . '_users', $where);
	}
}

$where['cl_forgot_password_1'] = $_GET['a'];
$where['cl_forgot_password_2'] = $_GET['b'];
$where['cl_id'] = $_GET['c'];

$obj = new ResetPasswordLink();
$user = $obj->checkUser($where);
if(!$user)
{
	header('Location: index.php');
	exit;
}

include_once "header_outer.php";
?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mx-4">
                    <div class="card-block p-4">
							<h1>FORGOT PASSWORD</h1>
							<form class="login-body col-xs-12" id="form" cluster-url="ajax/forgot_password_reset_password.php" cluster-warning="Restting Password" cluster-redirect="login.php">
								<div class="error-main"></div>
								 <div class="form-group col-xs-12 input-container">
									<input type="password" class="form-control top-margin login-input login-input-username" id="new_password" name="new_password" placeholder="New Password" />
									<div class="error-input"></div>
								</div>

								 <div class="form-group col-xs-12 input-container">
									<input type="password" class="form-control top-margin login-input login-input-username" id="confirm_password" name="confirm_password" placeholder="Confirm Password" />
									<div class="error-input"></div>
								</div>
								
								<button type="submit" class="btn btn-success top-margin login-submit"  id="btn-submit" >Reset Password</button>

								
									<a class="btn btn-primary top-margin pull-right" href="login.php">Login</a>
									<input type="hidden" value="<?php echo htmlspecialchars($_GET['a']) ?>" name="a" />
									<input type="hidden" value="<?php echo htmlspecialchars($_GET['b']) ?>" name="b" />
									<input type="hidden" value="<?php echo htmlspecialchars($_GET['c']) ?>" name="c" />
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		   <?php include_once "footer_outer.php"; ?>
