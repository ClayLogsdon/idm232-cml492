<?php

/*
*
* INFOATCLUSTER TECHNOLABS LLP ("COMPANY") CONFIDENTIAL
* Copyright (c) 2016-2017 INFOATCLUSTER TECHNOLABS LLP, All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains the property of INFOATCLUSTER TECHNOLABS LLP. The intellectual and technical concepts contained
* herein are proprietary to INFOATCLUSTER TECHNOLABS LLP and may be covered by Indian and Foreign Patents, patents in process, and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material is strictly forbidden unless prior written permission is obtained
* from COMPANY.  Access to the source code contained herein is hereby forbidden to anyone except current COMPANY employees, managers or contractors who have executed 
* Confidentiality and Non-disclosure agreements explicitly covering such access.
*
* The copyright notice above does not evidence any actual or intended publication or disclosure  of  this source code, which includes  
* information that is confidential and/or proprietary, and is a trade secret, of  COMPANY.   ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE, 
* OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
* LAWS AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS  
* TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.                
*
*
* @author Mohammed Shayas M K
* 
*/
include_once "../../config.php";
class validation
{
	public function checkRequired($requiredFields, $data)
	{
		$return = array();
		foreach($requiredFields AS $each)
		{
			if(!isset($data[$each]) || trim($data[$each]) == '')
			{
				$return[$each] = 'This field is required'; 
			}
		}

		if(!empty($return))
		{
			return $return;
		}
	}

	public function checkHTML($requiredFields, $data)
	{
		$return = array();
		foreach($requiredFields AS $each)
		{
			if($data[$each] != strip_tags($data[$each]))
			{
				$return[$each] = 'Sorry. Cannot insert this string'; 
			}
			else if(strpos($data[$each], '\'"'))
			{
				$return[$each] = 'Sorry. Cannot insert this string'; 
			}
		}

		if(!empty($return))
		{
			return $return;
		}
	}

	public function checkEmail($emailFields, $data)
	{
		$return = array();
		foreach($emailFields AS $each)
		{
			if (isset($data[$each]) && !filter_var($data[$each], FILTER_VALIDATE_EMAIL)) {
			  $return[$each] = "Invalid email format"; 
			}
		}

		if(!empty($return))
		{
			return $return;
		}
	}

	public function checkPassword($passwordFields, $data)
	{
		$return = array();
		foreach($passwordFields AS $each)
		{
			if (isset($data[$each]) && strlen($data[$each]) < 6) {
			  $return[$each] = "Password should have atleast 6 characters"; 
			}
		}

		if(!empty($return))
		{
			return $return;
		}
	}

	public function checkDate($dateFields, $data, $dateFormat)
	{
		$return = array();
		foreach($dateFields AS $each)
		{
			if (isset($data[$each])) {
				$date = DateTime::createFromFormat($dateFormat, $data[$each]);
				$date_errors = DateTime::getLastErrors();
				
				if ($date_errors['warning_count'] + $date_errors['error_count'] > 0) {
				    $return[$each] = 'Invalid Date Format';
				}
			  
			}
		}

		if(!empty($return))
		{
			return $return;
		}
	}

	public function checkNumeric($numericFields, $data)
	{
		$return = array();
		foreach($numericFields AS $each)
		{
			if (isset($data[$each]) && !is_numeric($data[$each])) {
			  $return[$each] = "This field should be numeric"; 
			}
		}

		if(!empty($return))
		{
			return $return;
		}
	}

	public function checkInteger($numericFields, $data)
	{
		$return = array();
		foreach($numericFields AS $each)
		{

			if (isset($data[$each]) && ((int)$data[$each] != $data[$each] || !is_numeric($data[$each]))) {
			  $return[$each] = "This field should be an integer"; 
			}
		}

		if(!empty($return))
		{
			return $return;
		}
	}

	public function setErrors($data)
	{
		$result = array();
		if(!empty($data))
		foreach($data AS $each)
		{
			foreach($each AS $key1 => $value1)
			{
				if(!isset($result[$key1]))
				{
					$result[$key1] = $value1 . '<br/>';
				}
				else
				{
					$result[$key1].= $value1 . ' <br/>';
				}
			}
		}

		return $result;
	}

	public function setErrorsAsText($data)
	{
		$result = '';
		if(!empty($data))
		foreach($data AS $each)
		{
			foreach($each AS $key1 => $value1)
			{
				
				$result.= $key1 . ':' . $value1 . '<br/>';
				
			}
		}

		return $result;
	}

	public function removeEmptyValues($data)
	{
		$result = array();
		if(!empty($data))
		foreach($data AS $key => $each)
		{
			if(trim($each) != '')
			{
				$result[COLUMN_PREFIX . '_' . $key] = $each;
			}
		}

		return $result;
	}

	public function setColumnPrefix($data)
	{
		$result = array();
		if(!empty($data))
		foreach($data AS $key => $each)
		{
			if(trim($each) != '')
			{
				$result[COLUMN_PREFIX . '_' . $key] = $each;
			}
			else
			{
				$result[COLUMN_PREFIX . '_' . $key] = null;
			}
		}

		return $result;
	}

	public function unsetValues($unsetFields, $data)
	{
		$return = array();
		foreach($unsetFields AS $each)
		{
			if (isset($data[$each])) {
				unset($data[$each]);
			}
		}

		return $data;
	}

	public function getFileType($fileMime)
	{
		$imageMimes = array('image/jpeg', 'image/png', 'image/gif');
		if(in_array($fileMime, $imageMimes))
		{
			return 'Image';
			exit;
		}

		$videoMimes = array('video/mp4', 'video/mpeg', 'video/x-msvideo', 'video/3gpp');
		if(in_array($fileMime, $videoMimes))
		{
			return 'Video';
			exit;
		}

		$audioMimes = array('audio/mp4', 'audio/mpeg');
		if(in_array($fileMime, $audioMimes))
		{
			return 'Audio';
			exit;
		}

		$applicationMimes = array('application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
									'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
									'text/csv', 'text/plain');
		if(in_array($fileMime, $applicationMimes))
		{
			return 'File';
			exit;
		}
	}
}