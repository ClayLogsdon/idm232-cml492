<?php
include_once "../../../config.php";
include_once "../../../database.php";
include_once "../validation.php";
include_once "../Helper.php";
include_once "../check_session_ajax.php";

include_once "../../auth.php";
$auth = array('admin','company');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    http_response_code(401);
	echo json_encode(array('error_text' => 'Authntication Error'));
	exit;
}
class addAjax extends database
{
   	public function index($data)
    {
    	return $this->insert('tb_category',$data);
    }
}


$obj = new addAjax();   

if(!isset($_POST['data']))
{
	http_response_code(400);
	echo json_encode(array('No input found'));
	exit;
}

 
								
$data = $_POST['data'];


$helper = new Helper();
$validation = new validation();

$data = $helper->changeSerialzeArrayValues($data);



$res = array();
$requiredFields = array('name');
$return = $validation->checkRequired($requiredFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}





if(!empty($res['error_description']))
{
	$result['error_description'] = $validation->setErrors($res['error_description']);
	$result['error_text'] = $validation->setErrors($res['error_description']);

	http_response_code(400);
	echo json_encode($result);
	exit;
}

if($user['cl_type'] =='company')
{
	$data['company_id']=$user['cl_id'];
}

$data = $validation->removeEmptyValues($data);


$obj = NEW AddAjax();
$res = $obj->index($data);
if(!$res)
{
	http_response_code(401);
	echo json_encode(array('error_text' => 'Something Went Wrong'));
	exit;
}

session_start();
$_SESSION['error_message'] = 'Category Added Successfully';
$_SESSION['error_type'] = 'success';

http_response_code(200);
echo json_encode(array('message' => 'Category Added Successfully'));
exit;