<?php
include_once "../../../config.php";
include_once "../../../database.php";
include_once "../validation.php";
include_once "../Helper.php";
include_once "../check_session_ajax.php";
require_once '../check_edit_page_ajax.php';
include_once "../../auth.php";
$auth = array('admin','company');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    http_response_code(401);
	echo json_encode(array('error_text' => 'Authntication Error'));
	exit;
}

class AddAjax extends database{
	public function index($data, $id)
	{
		$where['cl_id'] = $id;
		return $this->update('tb_category', $data, $where);
	}
}

if(!isset($_POST['data']))
{
	http_response_code(400);
	echo json_encode(array('No input found'));
	exit;
}

$data = $_POST['data'];
$helper = new Helper();
$validation = new validation();

$data = $helper->changeSerialzeArrayValues($data);

$res = array();
$requiredFields = array('name');
$return = $validation->checkRequired($requiredFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}



if(!empty($res['error_description']))
{
	$result['error_description'] = $validation->setErrors($res['error_description']);
	$result['error_text'] = 'Following errors occured while you were trying to submit data';

	http_response_code(400);
	echo json_encode($result);
	exit;
}


$unsetFields = array('id', 'deleted_at');
$data = $validation->unsetValues($unsetFields, $data);
$data = $validation->setColumnPrefix($data);

$obj = new AddAjax();
$res = $obj->index($data, $id);
if(!$res)
{
	http_response_code(401);
	echo json_encode(array('error_text' => 'Something Went Wrong'));
	exit;
}

session_start();
$_SESSION['error_message'] = 'Updated Successfully';
$_SESSION['error_type'] = 'success';

http_response_code(200);
echo json_encode(array('message' => 'Updated Successfully'));
exit;