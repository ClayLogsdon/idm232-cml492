<?php
include_once "../../config.php";
include_once "../../database.php";
include_once "validation.php";
include_once "Helper.php";
include_once "check_session_ajax.php";
require_once 'check_edit_page_ajax.php';
include_once "../auth.php";
$auth = array('admin');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    http_response_code(401);
	echo json_encode(array('error_text' => 'Authntication Error'));
	exit;
}

class DeletedAjax extends database{
	public function index($data, $id)
	{
		$where['cl_id'] = $id;
		return $this->update('tb_image', $data, $where);
	}

}


$data['deleted_at'] = date('Y-m-d H:i:s');



$obj = new DeletedAjax();
$res = $obj->index($data, $id);
if(!$res)
{
	http_response_code(401);
	echo json_encode(array('error_text' => 'Something Went Wrong'));
	exit;
}


http_response_code(200);
echo json_encode(array('message' => 'Deleted Successfully'));
exit;