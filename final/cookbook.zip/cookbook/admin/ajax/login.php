<?php
include_once "../../config.php";
include_once "../../database.php";
include_once "validation.php";
include_once "Helper.php";



class Login extends database{
	public function index($data)
	{
		$user = $this->fetchRow(TABLE_PREFIX . '_users', $data);
		if(!$user)
		{
			return 0;
			exit;
		}

		return $user;
		exit;
	}

	public function insertLog($data)
	{
		return $this->insert(TABLE_PREFIX . '_user_log', $data);
	}

	public function setSession($authCode, $userCode)
	{
		$data['cl_access_code'] = $authCode;
		$data['cl_client_code'] = $userCode;
		$data['cl_expiry_date'] = date('Y-m-d', strtotime('+ 5 days'));
		return $this->insert('tb_session_token', $data);
	}
}

if(!isset($_POST['data']))
{
	http_response_code(400);
	echo json_encode(array('No input found'));
	exit;
}

$data = $_POST['data'];
$helper = new Helper();
$validation = new validation();

$data = $helper->changeSerialzeArrayValues($data);

$res = array();
$requiredFields = array('email', 'password');
$return = $validation->checkRequired($requiredFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

$emailFields = array('email');
$return = $validation->checkEmail($emailFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

$passwordFields = array('password');
$return = $validation->checkPassword($passwordFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

if(!empty($res['error_description']))
{
	$result['error_description'] = $validation->setErrors($res['error_description']);
	$result['error_text'] = $validation->setErrors($res['error_description']);

	http_response_code(400);
	echo json_encode($result);
	exit;
}

$data = $validation->removeEmptyValues($data);

$password = $data[COLUMN_PREFIX .'_password'];
unset($data[COLUMN_PREFIX . '_password']);
$obj = new Login();


$user = $obj->index($data);
if(!$user)
{
	http_response_code(401);
	echo json_encode(array('error_text' => 'Your username or password is wrong. Please check1'));
	exit;
}

if(!password_verify($password, $user['cl_password'])) {
	http_response_code(401);
	echo json_encode(array('error_text' => 'Your username or password is wrong. Please check'));
	exit;
}

session_start();
if($user['cl_type']=='general')
{ 
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	$data1[COLUMN_PREFIX . '_ip']=$ip;
	$data1[COLUMN_PREFIX . '_user_id']=$user['cl_id'];
	$data1[COLUMN_PREFIX . '_login_time']=date('Y-m-d H:i:s');
	$obj->insertLog($data1);
	
} 
if($user['cl_type']=='coach')
{ 
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	$data2[COLUMN_PREFIX . '_ip']=$ip;
	$data2[COLUMN_PREFIX . '_user_id']=$user['cl_id'];
	$data2[COLUMN_PREFIX . '_login_time']=date('Y-m-d H:i:s');
	$obj->insertLog($data2);
	
} 

$authCode = hash('sha256', rand(10000000,99999999));
$session = $obj->setSession($authCode, $user['cl_code']);
if(!$session)
{
	http_response_code(401);
	echo json_encode(array('error_text' => 'Some thing went wrong while logging you in. Please try again.'));
	exit;
}

setcookie('token1',$authCode ,time() + (86400 * 30), "/");
setcookie('token2',$user[COLUMN_PREFIX . '_code'] ,time() + (86400 * 30), "/");
http_response_code(200);
echo json_encode(array('message' => 'You are logged in successfully. Please wait while you are being redirectred.', 'type' => $user[COLUMN_PREFIX . '_type']));
exit;