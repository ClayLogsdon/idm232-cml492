<?php

include_once "../../config.php";
include_once "../../database.php";
include_once "validation.php";
include_once "Helper.php";



if(!isset($_FILES["file1"]["name"]) && !isset($_FILES["file2"]["name"]))
{
	http_response_code(404);
	echo json_encode(array('error_text' => 'File Not Found'));
	exit;
}


if(isset($_FILES["file1"]["name"]))
{
    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["file1"]["tmp_name"]);
    $target_dir = "../../img/avatars/";
    $newName = rand(100000,999999) . '_' . date('dmyHis') . '_' . basename($_FILES["file1"]["name"]);
    $tmpName = $_FILES["file1"]["tmp_name"];
    $fileSize = $_FILES["file1"]["size"];
    $actualName = $_FILES["file1"]["tmp_name"];

    $fileName = basename($newName, '.png');

    $url = DOMAIN . '/img/avatars/' . $newName;
}
else if(isset($_FILES["file2"]["name"]))
{
    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["file2"]["tmp_name"]);
    $target_dir = "../../img/avatars/inactive/";
    $newName = rand(100000,999999) . '_' . date('dmyHis') . '_' . basename($_FILES["file2"]["name"]);

    $tmpName = $_FILES["file2"]["tmp_name"];
    $fileSize = $_FILES["file2"]["size"];
    $actualName = $_FILES["file2"]["tmp_name"];

    $fileName = basename($newName, '.png');

    $url = DOMAIN . '/img/avatars/inactive/' . $newName;
}


$target_file = $target_dir . $newName;
$message = '';
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));



if($check !== false) {
    
} else {
    $message.="File is not an image.";
}

// Check if file already exists
if (file_exists($target_file)) {
    $message.="Sorry, file already exists.";
}
// Check file size
if ($fileSize > 1000000) {
    $message.="Sorry, Images larger than 1 mb not allowed.";
}
// Allow certain file formats
if($imageFileType != "png") {
    $message.="Sorry, only PNG files are allowed.";
}
// Check if $uploadOk is set to 0 by an error
if (trim($message) != '') {
    http_response_code(400);
    echo json_encode(['error_text' => $message]);
    exit;
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($tmpName, $target_file)) {
        http_response_code(200);
        echo json_encode(['message' => 'File Uploaded Successfully', 'file' => $fileName,  'url' => $url,  'fileType' => 'image']);
        exit;
    } else {
        http_response_code(500);
        echo json_encode(['error_text' => 'Error while uploading file']);
        exit;
    }
}