<?php
session_start();
include_once "../../config.php";
include_once "../../database.php";
include_once "validation.php";
include_once "Helper.php";
include_once "check_session_ajax.php";

class ResetPassword extends database{
	public function index($data, $userID)
	{
		$where[COLUMN_PREFIX . '_id'] = $userID;
		$data[COLUMN_PREFIX . '_password'] = password_hash($data[COLUMN_PREFIX . '_new_password'], PASSWORD_BCRYPT);
		unset($data[COLUMN_PREFIX . '_new_password']);
		unset($data[COLUMN_PREFIX . '_confirm_password']);
		
		return $this->update(TABLE_PREFIX . '_users', $data, $where);
	}

}

if(!isset($_POST['data']))
{
	http_response_code(400);
	echo json_encode(array('No input found'));
	exit;
}


$data = $_POST['data'];
$helper = new Helper();
$validation = new validation();

$data = $helper->changeSerialzeArrayValues($data);

$requiredFields = array('password', 'confirm_password', 'new_password');
$res = array();
$return = $validation->checkRequired($requiredFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

$passwordFields = array('confirm_password', 'new_password');
$return = $validation->checkPassword($passwordFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

if($data['confirm_password'] != $data['new_password'])
{
	http_response_code(400);
	echo json_encode(array('error_text' => 'Password and confirm password does not match'));
	exit;
}

if(!empty($res['error_description']))
{
	$result['error_description'] = $validation->setErrors($res['error_description']);
	http_response_code(400);
	echo json_encode($result);
	exit;
}


if(!password_verify($data['password'], $user[COLUMN_PREFIX . '_password'])) {
	http_response_code(400);
	echo json_encode(array('error_description' => array('password' => 'Current Password does not match')));
	exit;
}

$unsetFields = array('id', 'email', 'username', 'type');
$data = $validation->unsetValues($unsetFields, $data);


$data = $validation->removeEmptyValues($data, $id);

$obj = new ResetPassword();
$res = $obj->index($data, $user[COLUMN_PREFIX . '_id']);
if(!$res)
{
	http_response_code(500);
	echo json_encode(array('error_text' => 'Something Went Wrong While Updating Password. Please try again'));
	exit;
}

http_response_code(200);
echo json_encode(array('message' => 'Password Updated Successfully'));
exit;