                                                                                                 <?php
function send_email($email,$name, $subject, $body)
{ 

    /* SMTP */

	require_once 'PHPMailer/PHPMailerAutoload.php';
    $mail = new PHPMailer;

    $mail->isSMTP();                                      // Set mailer to use SMTP
   // $mail->SMTPDebug = 4;      
    $mail->Host = SMTP_HOST;  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = SMTP_EMAIL;                 // SMTP username
    $mail->Password = SMTP_PASSWORD;
    $mail->SMTPSecure = SMTP_ENCRYPTION;                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = SMTP_PORT;


    $mail->setFrom(SMTP_SET_FROM_EMAIL, SMTP_SET_FROM_NAME);
    $mail->addAddress($email, $name);
    $mail->Subject = $subject;
    $mail->Body    = '<table style="width:100%;border:1px solid lightgray"><tr><td style="text-align:left;border-bottom:1px solid lightgray;;padding:15px"><img src="http://mayandhettler.com/wp-content/uploads/2018/08/logo1.png" style="max-width:200px" /></td></tr><tr><td><b style="font-size:17px;;padding:15px">' . $body . '</b></td></tr><tr><td style="border-top:1px solid lightgray;padding:15px">Regards,<br/>Drs. May, Hettler & Associates <br/>www.mayandhettler.com/</td></tr></table>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    if(!$mail->send())
    {
        return 0;
    } 
    else
    {
        return 1;
    }

/*ini_set('sendmail_from', 'noreplay@clusterinfos.com');
ini_set('sendmail_path', '/usr/sbin/sendmail -t -i -f noreplay@clusterinfos.com');
$headers = "From: noreplay@clusterinfos.com\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
						//$headers .= "Reply-To: shayasmk@gmail.com\r\n";
						$headers .= "MIME-Version: 1.0\r\n";
						$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
						$headers .= "X-Mailer: PHP/".phpversion();   

						return mail('shayasmk@gmail.com',$subject, $body, $headers); */

}
