<?php
include_once "../../config.php";
include_once "../../database.php";
include_once "validation.php";
include_once "Helper.php";
include_once "send_email.php";

class ForgotPassword extends database{
	public function index($where)
	{
		//$where[COLUMN_PREFIX . '_type'] = 'general';
		return $this->fetchRow(TABLE_PREFIX . '_users', $where);
	}

	public function updateUser($data, $where)
	{
		return $this->update(TABLE_PREFIX . '_users', $data, $where);
	}
}

if(!isset($_POST['data']))
{
	http_response_code(400);
	echo json_encode(array('No input found'));
	exit;
}

$data = $_POST['data'];
$helper = new Helper();
$validation = new validation();

$data = $helper->changeSerialzeArrayValues($data);

$res = array();

$requiredFields = array('email');
$return = $validation->checkRequired($requiredFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}


$emailFields = array('email');
$return = $validation->checkEmail($emailFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

if(!empty($res['error_description']))
{
	$result['error_description'] = $validation->setErrors($res['error_description']);
	$result['error_text'] = $validation->setErrors($res['error_description']);

	http_response_code(400);
	echo json_encode($result);
	exit;
}

$data = $validation->removeEmptyValues($data);

$obj = new ForgotPassword();
$user = $obj->index($data);
if(!$user)
{
	http_response_code(401);
	echo json_encode(array('error_text' => 'User Not Found'));
	exit;
}


$data['cl_forgot_password_1'] = md5(rand(1000000,9999999));
$data['cl_forgot_password_2'] = md5(rand(1000000,9999999));
$where['cl_id'] = $user['cl_id'];
$resUser = $obj->updateUser($data, $where);
if(!$resUser)
{
	http_response_code(500);
	echo json_encode(array('error_text' => 'Something went wrong. Please try again'));
	exit;
}

$emailRes = send_email($user[COLUMN_PREFIX . '_email'], $user[COLUMN_PREFIX . '_first_name'], 'Reset Password Link', 'Please click the below link to reset your password.<br/><a href="' . DOMAIN . '/reset_password_link.php?a=' . $data['cl_forgot_password_1'] . '&b=' . $data['cl_forgot_password_2'] . '&c=' . $user['cl_id'] . '" style="padding-left:15px">' . DOMAIN . '/reset_password_link.php?a=' . $data['cl_forgot_password_1'] . '&b=' . $data['cl_forgot_password_2'] . '&c=' . $user['cl_id'] . '</a>');
if($emailRes)
{

	http_response_code(200);
	echo json_encode(array('message' => 'Reset link is successfully sent to your email. Please check your email for further details.'));
	exit;
}
else
{
	http_response_code(500);
	echo json_encode(array('message' => 'Something went wrong while sending email'));
	exit;
}