<?php

include_once "../../config.php";
include_once "../../database.php";
include_once "validation.php";
include_once "Helper.php";



if(!isset($_FILES["file"]["name"]))
{
	http_response_code(404);
	echo json_encode(array('error_text' => 'File Not Found'));
	exit;
}

$target_dir = "../uploads/";
$newName = rand(100000,999999) . '_' . date('dmyHis') . '_' . basename($_FILES["file"]["name"]);
$target_file = $target_dir . $newName;
$message = '';
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
$check = getimagesize($_FILES["file"]["tmp_name"]);
if($check !== false) {
    
} else {
    $message.="File is not an image.";
}

// Check if file already exists
if (file_exists($target_file)) {
    $message.="Sorry, file already exists.";
}
// Check file size
if ($_FILES["file"]["size"] > 1000000) {
    $message.="Sorry, Images larger than 1 mb not allowed.";
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
    $message.="Sorry, only JPG, JPEG, PNG files are allowed.";
}
// Check if $uploadOk is set to 0 by an error
if (trim($message) != '') {
    http_response_code(400);
    echo json_encode(['error_text' => $message]);
    exit;
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        http_response_code(200);
        echo json_encode(['message' => 'File Uploaded Successfully', 'url' => DOMAIN . '/admin/uploads/' . $newName  , 'file' => $newName, 'actualName' => basename($_FILES["file"]["name"]), 'fileType' => 'image']);
        exit;
    } else {
        http_response_code(500);
        echo json_encode(['error_text' => 'Error while uploading file']);
        exit;
    }
}