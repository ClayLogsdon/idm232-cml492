<?php
include_once "../../config.php";
include_once "../../database.php";
include_once "validation.php";
include_once "Helper.php";
include_once "send_email.php";

class ForgotPassword extends database{
	public function checkUser($where)
	{

		//$where[COLUMN_PREFIX . '_type'] = 'general';
		return $this->fetchRow(TABLE_PREFIX . '_users', $where);
	}

	public function updateUser($data, $where)
	{
		
		if(isset($data['cl_a']))
		{
			unset($data['cl_a']);
		}

		if(isset($data['cl_b']))
		{
			unset($data['cl_b']);
		}

		if(isset($data['cl_c']))
		{
			unset($data['cl_c']);
		}
		return $this->update(TABLE_PREFIX . '_users', $data, $where);
	}
}


if(!isset($_POST['data']))
{
	http_response_code(400);
	echo json_encode(array('No input found'));
	exit;
}

$data = $_POST['data'];
$helper = new Helper();
$validation = new validation();

$data = $helper->changeSerialzeArrayValues($data);

if(!isset($data['a']) || !isset($data['b']) || !isset($data['c']) || !is_numeric($data['c']) || trim($data['a']) == '' || trim($data['b']) == '' || trim($data['c']) == '' || trim($data['a']) == null || trim($data['b']) == null || trim($data['a']) == 'null' || trim($data['b']) == 'null' || trim($data['c']) == 'null' || trim($data['c']) == null)
{
	http_response_code(400);
	echo json_encode(array('error_text' => 'No input found'));
	exit;
}

$where['cl_forgot_password_1'] = $data['a'];
$where['cl_forgot_password_2'] = $data['b'];
$where['cl_id'] = $data['c'];

$requiredFields = array('new_password', 'confirm_password');
$res = array();
$return = $validation->checkRequired($requiredFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

$passwordFields = array('new_password', 'confirm_password');
$return = $validation->checkPassword($passwordFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

if(!empty($res['error_description']))
{
	$result['error_description'] = $validation->setErrors($res['error_description']);
	$result['error_text'] = $validation->setErrors($res['error_description']);

	http_response_code(400);
	echo json_encode($result);
	exit;
}

if($data['new_password'] != $data['confirm_password'])
{
	$result['error_text'] ='Password and confirm apssword does not match';
	http_response_code(400);
	echo json_encode($result);
	exit;
}


$data = $validation->removeEmptyValues($data);

$obj = new ForgotPassword();
$user = $obj->checkUser($where);
if(!$user)
{
	http_response_code(401);
	echo json_encode(array('error_text' => 'User Not Found'));
	exit;
}

$data['cl_forgot_password_1'] = null;
$data['cl_forgot_password_2'] = null;
$data['cl_password'] = password_hash($data['cl_confirm_password'], PASSWORD_BCRYPT);
unset($data['cl_new_password']);
unset($data['cl_confirm_password']);

$where1['cl_id'] = $user['cl_id'];

$resUser = $obj->updateUser($data, $where1);
if(!$resUser)
{
	http_response_code(500);
	echo json_encode(array('error_text' => 'Something went wrong. Please try again'));
	exit;
}

http_response_code(200);
echo json_encode(array('message' => 'Password reset successful. Redirecting....'));
exit;