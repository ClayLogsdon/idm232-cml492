<?php 
include_once "../../config.php";
include_once "../../database.php";
if(!isset($_SESSION['user_id']) || $_SESSION['user_id'] == '')
{
	http_response_code(401);
	echo json_encode(array("error_text" => "User Not Authenticated"));
	exit;
}

class userSession extends database{
	function checkUser($userID)
	{
		$where[COLUMN_PREFIX . '_id'] = $userID;
		return $this->fetchRow(TABLE_PREFIX . '_users', $where);
	}

	function checkPayment($id)
	{
		$where[0]['cl_user_id']['value'] = $id;
		$where[0]['cl_user_id']['operator'] = '=';

		$where[1]['cl_expiry_date']['value'] = date("Y-m-d");
		$where[1]['cl_expiry_date']['operator'] = '>=';

		$where[2]['cl_status']['value'] = 'succeeded';
		$where[2]['cl_status']['operator'] = '=';
		return $this->fetchRow(TABLE_PREFIX . '_active_packages', $where);
	}
}

$userID = $_SESSION['user_id'];

$obj = new userSession();
$currentUser = $obj->checkUser($userID);
if(!$currentUser || $currentUser[COLUMN_PREFIX . '_type'] != 'general')
{
	http_response_code(401);
	echo json_encode(array("error_text" => "User Not Authenticated"));
	exit;
}

if($currentUser['cl_register_1'] != null || $currentUser['cl_register_2'] != null)
{
	http_response_code(401);
	echo json_encode(array("error_text" => "Account Not Confirmed"));
	exit;
}