<?php
if(!isset($_GET['id']) || !is_numeric($_GET['id']))
{
	http_response_code(404);
	echo json_encode(array('error_text' => 'Not Found'));
	exit;
}

$id = $_GET['id'];