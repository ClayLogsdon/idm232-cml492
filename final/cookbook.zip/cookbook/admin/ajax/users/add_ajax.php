<?php
include_once "../../../config.php";
include_once "../../../database.php";
include_once "../validation.php";
include_once "../Helper.php";
include_once "../check_session_ajax.php";

include_once "../../auth.php";
$auth = array('admin');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    http_response_code(401);
	echo json_encode(array('error_text' => 'Authntication Error'));
	exit;
}
class addAjax extends database
{
   public function index($data)
	{

		$data['cl_password'] = password_hash($data['cl_password'], PASSWORD_DEFAULT);
		
		$count = $this->current_count();
		$data['cl_user_code'] = $count['cl_prefix'] . '-' . $count['cl_count'];
		$data1['cl_count']=$count['cl_count'] + 1;
		$where1['cl_id']=$count['cl_id'];

		$this->dbh = $this->connectPDO1();
		$this->dbh->beginTransaction();
        try
        {
			$autoID = $this->update1('tb_auto_incre', $data1, $where1);
			if(!$autoID)
			{
				$this->dbh->rollback();
				return 0;
				exit;
			}
			
			$userID = $this->insert1($this->dbh,'tb_users', $data);
			if(!$userID)
			{
				$this->dbh->rollback();
				return 0;
				exit;
			}

			$where2['cl_id'] = $userID;

			$data2['cl_code']= md5($userID);
			
			$res = $this->update1('tb_users', $data2, $where2);
			if(!$res)
			{
				$this->dbh->rollback();
				return 0;
				exit;
			}

			
			

			$this->dbh->commit();
			return 1;
			exit;
		}
        catch (PDOException $e) {
            // roll back transaction
            $this->dbh->rollback();
            return 0;
        }
		
		//$this->update('tb_auto_incre', $data1,$where1);
		//return $this->insert('tb_user', $data);
	}

	public function checkEmail($email)
    {
        $where['cl_email'] = $email;
        return $this->fetchRow('tb_users', $where);
    }

    public function current_count()
    {
         return $this->fetchRow('tb_auto_incre', ['cl_type' => 'User']);
    }
}


$obj = new addAjax();   

if(!isset($_POST['data']))
{
	http_response_code(400);
	echo json_encode(array('error_text' => 'No input found'));
	exit;
}



$data = $_POST['data'];
$helper = new Helper();
$validation = new validation();

$data = $helper->changeSerialzeArrayValues($data);



$res = array();
$requiredFields = array('first_name', 'last_name','email', 'password', 'phone');
$return = $validation->checkRequired($requiredFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}


$htmlFields = array('first_name','last_name', 'email', 'password');
$return = $validation->checkHTML($htmlFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}


$emailFields = array('email');
$return = $validation->checkEmail($emailFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

$passwordFields = array('password');
$return = $validation->checkPassword($passwordFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

$dateFields = array('birthday');
$return = $validation->checkDate($dateFields, $data, 'd M Y');
if($return)
{
	$res['error_description'][] = $return;
}


$obj = NEW AddAjax();
$emailCheck = $obj->checkEmail($data['email']);
if($emailCheck)
{
	$res['error_description'][] = ['email' => 'Email Already Exists'];
}


if(!empty($res['error_description']))
{
	$result['error_description'] = $validation->setErrors($res['error_description']);
	$result['error_text'] = $validation->setErrors($res['error_description']);

	http_response_code(400);
	echo json_encode($result);
	exit;
}

$data = $validation->removeEmptyValues($data);


$data['cl_birthday']=date('Y-m-d',strtotime($data['cl_birthday']));

$res = $obj->index($data);
if(!$res)
{
	http_response_code(401);
	echo json_encode(array('error_text' => 'Something Went Wrong'));
	exit;
}

session_start();
$_SESSION['error_message'] = 'User Added Successfully';
$_SESSION['error_type'] = 'success';

http_response_code(200);
echo json_encode(array('message' => 'User Added Successfully'));
exit;