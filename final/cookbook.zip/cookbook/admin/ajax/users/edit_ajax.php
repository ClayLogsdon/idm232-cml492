<?php
include_once "../../../config.php";
include_once "../../../database.php";
include_once "../validation.php";
include_once "../Helper.php";
include_once "../check_session_ajax.php";
require_once '../check_edit_page_ajax.php';
include_once "../../auth.php";
$auth = array('admin');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    http_response_code(401);
	echo json_encode(array('error_text' => 'Authntication Error'));
	exit;
}

class AddAjax extends database{
	public function index($data, $id)
	{
		if(trim($data['cl_password']) != '')
		{
			$data['cl_password'] = password_hash($data['cl_password'], PASSWORD_DEFAULT);
		}
		else
		{
			unset($data['cl_password']);
		}

		$where['cl_id'] = $id;
		return $this->update('tb_users', $data,$where);
	}

	public function checkEmail($email, $id)
    {
        $where[0]['cl_email']['value'] = $email;
        $where[0]['cl_email']['operator'] = '=';

    	$where[1]['cl_id']['value'] = $id;
        $where[1]['cl_id']['operator'] = '!=';
        return $this->fetchRow('tb_users', $where);
    }

    public function current_count()
    {
         return $this->fetchRow('tb_auto_incre');
    }

	

}

if(!isset($_POST['data']))
{
	http_response_code(400);
	echo json_encode(array('No input found'));
	exit;
}

$data = $_POST['data'];
$helper = new Helper();
$validation = new validation();

$data = $helper->changeSerialzeArrayValues($data);

$res = array();
$requiredFields = array('first_name','last_name','type', 'email', 'phone', 'address', 'country_id', 'location');
$return = $validation->checkRequired($requiredFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

$htmlFields = array('first_name','email', 'password','phone', 'address', 'country_id', 'location');
$return = $validation->checkHTML($htmlFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

$emailFields = array('email');
$return = $validation->checkEmail($emailFields, $data);
if($return)
{
	$res['error_description'][] = $return;
}

$obj = NEW AddAjax();
$emailCheck = $obj->checkEmail($data['email'], $id);
if($emailCheck)
{
	$res['error_description'][] = ['email' => 'Email Already Exists'];
}

$return = $validation->checkHTML($requiredFields, $data);
if($return)
{
    $res['error_description'][] = $return;
}

if(trim($data['password']) != '')
{
	$passwordFields = array('password');
	$return = $validation->checkPassword($passwordFields, $data);
	if($return)
	{
		$res['error_description'][] = $return;
	}
}

if(!empty($res['error_description']))
{
	$result['error_description'] = $validation->setErrors($res['error_description']);
	$result['error_text'] = 'Following errors occured while you were trying to submit data';

	http_response_code(400);
	echo json_encode($result);
	exit;
}
$data['birthday']=date('Y-m-d',strtotime($data['birthday']));

$unsetFields = array('id', 'deleted_at');
$data = $validation->unsetValues($unsetFields, $data);
$data = $validation->setColumnPrefix($data);

$res = $obj->index($data, $id);
if(!$res)
{
	http_response_code(401);
	echo json_encode(array('error_text' => 'Something Went Wrong'));
	exit;
}

session_start();
$_SESSION['error_message'] = 'User Updated Successfully';
$_SESSION['error_type'] = 'success';

http_response_code(200);
echo json_encode(array('message' => 'User Updated Successfully'));
exit;