<?php
session_start();
require_once '../../config.php';
require_once '../../database.php';
require_once '../check_session.php';

require_once '../auth.php';

$auth = array('admin', 'company');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    header('Location: ../index.php');
    exit;
}



class Alist extends database{
	
  public function all($search, $page)
  {
      if(trim($search) == '')
      {
	    return $this->fetchAll("tb_recipe", null, 'created_at', 'DESC', ($page - 1) * NO_OF_RECORDS, NO_OF_RECORDS);
      }
      else
      {
          $sql = ' SELECT * FROM  tb_recipe WHERE cl_name LIKE ? ORDER BY created_at DESC LIMIT ' . ($page - 1) * NO_OF_RECORDS . 
                  ',' . NO_OF_RECORDS;
          return $this->callQuery($sql, [$search . '%']);
      }
  }
   public function allr($search, $page,$id)
  {
       if(trim($search) == '')
      {
            $where['cl_category_id'] = $id;
	    return $this->fetchAll("tb_recipe", $where, 'created_at', 'DESC', ($page - 1) * NO_OF_RECORDS, NO_OF_RECORDS);
      }
      else
      {
          $sql = ' SELECT * FROM  tb_recipe WHERE cl_name LIKE ? AND cl_category_id=? ORDER BY created_at DESC LIMIT ' . ($page - 1) * NO_OF_RECORDS . 
                  ',' . NO_OF_RECORDS;
          return $this->callQuery($sql, [$search . '%', $id]);
      }
  }
}

$search = '';
if(isset($_GET['search']))
{
    $search = $_GET['search'];
}

$page = 1;
if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 1)
{
  $page = $_GET['page'];
}


$obj = new Alist();
if(isset($_GET['id']) && $_GET['id'] != "")
{
	$id = $_GET['id'];
	$list = $obj->allr($search, $page,$id);
}
else
{
$list = $obj->all($search, $page);
}
include '../header.php';
?>
	
<!-- Main content -->
    <main class="main pb-lg-5 col-12">
	
		<div class="container text-center search-container mt-2">
			<form action="">
			  <input class="search px-3" type="text" placeholder="Search.." name="search">
			  <button type="submit" class="search-icon"><img src="../images/Search Icon.png"></button>
			</form>
		  </div>
    <div class="container">
		<center><a href="add.php" class="btn btn-secondary mb-5 btn-add">Add Recipe</a></center>
		<?php include_once "../check_errors.php";?>
      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        
		  <?php
                      if(!empty($list))
                      foreach($list AS $pos)
                      {
						
                        ?>
        <div class="col-md-4 cluster-container">
          <div class="card shadow-sm">
		  
            <?php
				if($pos[COLUMN_PREFIX . '_image'] =="")
				{ ?>
					<img class="bd-placeholder-img card-img-top" src="<?php echo DOMAIN ?>/admin/uploads/no-image.jpg" width="100%" height="300"/>
				<?php }
				else
				{
			?>
			<img class="bd-placeholder-img card-img-top" src="<?php echo DOMAIN ?>/admin/uploads/<?php echo htmlspecialchars($pos[COLUMN_PREFIX . '_image']) ;?>" width="100%" height="300"/>
			<?php
				}
				?>
            <div class="card-body">
              <h3 class="card-text text-center recipe-n"><?php echo htmlspecialchars($pos[COLUMN_PREFIX . '_name']); ?> </h3>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group col-12">
                  <a href="../../recipe-view.php?id=<?php echo htmlspecialchars($pos['cl_id']);?>" target="_blank" class="btn btn-primary mr-1"><i class="fa fa-eye"></i></a> 
				   <a href="edit.php?id=<?php echo htmlspecialchars($pos['cl_id']);?>" class="btn btn-success  mr-1"><i class="fa fa-edit"></i></a>
				<button type="button" class="btn  btn-delete btn-danger" cluster-confirm="Are you sure you want to delete this data?" cluster-href="../ajax/recipe/delete_ajax.php?id=<?php echo htmlspecialchars($pos['cl_id']);?>"><i class="fa fa-trash"></i></button>
                <div class="error-input"></div>
				</div>
                <!--<small class="text-muted">9 mins</small>-->
              </div>
            </div>
          </div>
        </div>
          <?php
						  
                      }
                      ?>
		<center>
		<nav aria-label="Page navigation example">
					  <ul class="pagination justify-content-center">
						<?php
						if($page > 1)
						  { ?>
						<li class="page-item"><a class="page-link" href="?page=<?php echo ($page - 1) ?>">Previous</a></li>
						<?php
					  }
						if(count($list) >= NO_OF_RECORDS)
						  { ?>
						<li class="page-item"><a class="page-link" href="?page=<?php echo ($page + 1) ?>">Next</a></li>
					  <?php } ?>
					  </ul>
					</nav>
		</center>
      </div>
    </div>
 
  
      
</main>
      
<?php
include '../right_side.php';
?>
</div>
<?php
include '../footer.php';
?>