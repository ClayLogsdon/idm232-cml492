<?php
session_start();
require_once '../../config.php';
require_once '../../database.php';
require_once '../check_session.php';
require_once '../check_edit_page.php';
require_once '../auth.php';

$auth = array('admin', 'company');
$authRes = checkAuth($auth, $user);
if(!$authRes)
{
    header('Location: ../index.php');
    exit;
}



class Recipe extends database{
	public function getCurrentPost($id)
	{
		$where['cl_id'] = $id;
		return $this->fetchRow('tb_recipe', $where);
	}
	

}

$obj = new Recipe();
$data = $obj->getCurrentPost($id);
include '../header.php';
?>
	
<!-- Main content -->
    <main class="main pb-lg-5">
	
		<div class="container">
			<div class="col-md-12 mb-5">
					<a href="list.php?id=<?php echo htmlspecialchars($data[COLUMN_PREFIX . '_category_id']) ;?>"><img src="../images/Vector.png"/></a>
				</div>
			<div class="col-md-8 m-auto">
				  
								<img class="bd-placeholder-img card-img-top" src="<?php echo DOMAIN ?>/admin/uploads/<?php echo htmlspecialchars($data[COLUMN_PREFIX . '_image']) ;?>" width="100%" height="380">
								
					  <h1 class="recipe-name text-center text-capitalize"><?php echo htmlspecialchars($data[COLUMN_PREFIX . '_name']) ;?></h1>
					  
					
				  
					</div>
					 <div class="col-md-10 m-auto p-3 description-div">
					  <p class="text-recipe"><?php echo htmlspecialchars($data[COLUMN_PREFIX . '_description']) ;?></p>
				</div>
                  <div class="col-md-10 m-auto p-3">
					<h3 class="recipe-sub">Ingredients</h3>
					<p class="text-recipe"><?php echo $data[COLUMN_PREFIX . '_ingradient'] ;?></p>
					<h3 class="recipe-sub">Instructions</h3>
					<p class="text-recipe"><?php echo $data[COLUMN_PREFIX . '_instruction'] ;?></p>
				</div>
		  </div>
    
 
  
      
</main>
      
<?php
include '../right_side.php';
?>
</div>
<?php
include '../footer.php';
?>