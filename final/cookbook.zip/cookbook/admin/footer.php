</div>

 <!--  <script src="<?php echo DOMAIN ?>/js/admin_ajax.js"></script>
  <script src="<?php echo DOMAIN ?>/js/admin_ajax_edit.js"></script>

  <script src="<?php echo DOMAIN ?>/js/user_ajax.js"></script>
  <script src="<?php echo DOMAIN ?>/js/user_ajax_edit.js"></script>-->
  <!-- Bootstrap and necessary plugins -->

  <script src="<?php echo DOMAIN ?>/admin/node_modules/popper.js/dist/umd/popper.min.js"></script>
  <script src="<?php echo DOMAIN ?>/admin/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="<?php echo DOMAIN ?>/admin/node_modules/pace-progress/pace.min.js"></script>

  <script src="<?php echo DOMAIN ?>/admin/dropzone/dist/dropzone.js"></script>

  <!-- CoreUI main scripts -->

  <script src="<?php echo DOMAIN ?>/admin/js/app.js"></script>

  <!-- Plugins and scripts required by this views -->

  <!-- Custom scripts required by this view -->
  
<!--   <script src="/datepicker/bootstrap-datepicker.js"></script>-->
  <script src="<?php echo DOMAIN ?>/admin/datepicker/dist/zebra_datepicker.src.js"></script>
    <script>
        $('input.datepicker').Zebra_DatePicker({
            format : "d M Y"
        });

        $('input.datepicker_month').Zebra_DatePicker({
            format : "d M"
        });

        $('input.datepicker_month_year').Zebra_DatePicker({
            format : "M Y"
        });

        $('input.datepicker_days').Zebra_DatePicker({
          format : "D"
        })

        $('input.datepicker_year').Zebra_DatePicker({
          format : "Y"
        })

        $('input.datepicker_event').Zebra_DatePicker({
          format : "d M Y",
          disabled_dates: ['* * * 1-5']
        })

        $(document).ready(function() {
          $('.datatable').DataTable({
            "bPaginate": false,
            responsive: true,
            searching: false, 
            paging: false, 
            info: false
          });
      } );

    </script>
   
        
        <script>
      $(document).ready(function(){
         $('.dropdown .nav-link').click(function(){
             console.log("a");
             var parent = $(this).parents('.dropdown').first();
             $(parent).find('.dropdown-menu').toggle();
         });
         
         $('.each-link').click(function(){
             $('#notificationModal .modal-body').text('Please wait while we are switiching Companies');
             $('#notificationModal').modal('show');
            var company_id = $(this).attr('data-company_id'); 
            $.get('/api/v1/auth/session/set', {'company_id': company_id}, function(res){
                window.location.href = '/';
            });
         });
         
      });
      CKEDITOR.replaceAll( 'ckedit' ); 
      </script>
</body>
</html>